package bank;
import java.util.ArrayList;
public class BankAccount {

	String state = "open";
	int accountNumber = 0;
	private double balance = 0.0;
	private ArrayList<Double> TransactionList = new ArrayList<Double>();
	
	public BankAccount(int anAccountNumber,double initialBalance){
			if(state.equals("true")){
				accountNumber = accountNumber += anAccountNumber;
				TransactionList.add(initialBalance);
				balance = balance += initialBalance;
			}
		};
		
	void suspend(){
			state.equals("suspend");
		}
	void close(){
			state.equals("close");
		}
	void reOpen(){
			state.equals("reopen");
		}
	boolean isOpen(){
			if(state.equals("open")){
				return true;
			}else{
				return false;
			}
		}
	boolean isSuspended(){
			if(state.equals("suspend")){
				return true;
			}else{
				return false;
			}
		}
	boolean isClose(){
			if(state.equals("close")){
				return true;
			}else{
				return false;
			}
		}
	void deposit(double amount){
		try{
		   if(isOpen()== true && amount > 0){
				TransactionList.add(amount);
				}else{
					System.out.println("�L�ıb��Φs�����B���~");
				}
		}catch(Exception e){
			        System.out.println("��J���~�A�Э��s��J");
		}
		this.balance = this.balance + amount;
	 }	
	void withdraw(double amount){
	    try{
		   if(isOpen()== true && amount > 0 && amount <= this.balance){
			   TransactionList.add(0-amount);
				}else{
					System.out.println("�L�ıb��δ������B���~");
				}
		}catch(Exception e){
			 		System.out.println("��J���~�A�Э��s��J");
		}
		this.balance = this.balance - amount;
	}
	void addTransaction(double amount){
		TransactionList.add(amount);
	}
    String getTransactions(){
    	String transactionList = "Account #" + accountNumber + "transactions:\n\n";
    	int i = 1;
    	for(double num : TransactionList){
    		transactionList = transactionList + i + ":" + num +"\n";
    	}
    	return transactionList + "End of transactions\n\n";
    }
   int retrieveNumberofTransactions(){
	   return TransactionList.size();
   }
   String getStatus(){
	   return state;
   }
   double getBalance(){
	   return this.balance;
   }



}
