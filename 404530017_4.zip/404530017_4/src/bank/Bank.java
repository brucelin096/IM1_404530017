package bank;

import java.util.ArrayList;
public class Bank {
	ArrayList<BankAccount> Account = new ArrayList<BankAccount>();
	
	public Bank(){
		
	} 
	
	public BankAccount FindBankAccount(int AccountNumber){
		BankAccount tempAccount = null;
		for(BankAccount account : Account){
			if(account.accountNumber == AccountNumber){
				tempAccount = account;
			}
		}
		return tempAccount;
	}
	void addAccount(int accountNumber , double initialBalance){
		BankAccount tempAccount = new BankAccount(accountNumber,initialBalance);
		Account.add(tempAccount);
	}
	void deposit(int accountNumber , double initialBalance ){
		FindBankAccount(accountNumber).deposit(initialBalance);
	}
	void withdraw(int accountNumber , double initialBalance ){
		FindBankAccount(accountNumber).withdraw(initialBalance);
	}
	double getBalance(int accountNumber){
		return FindBankAccount(accountNumber).getBalance();
	}
	void reOpenAccount(int accountNumber){
		FindBankAccount(accountNumber).reOpen();
	}
	void closeAccount(int accountNumber){
		FindBankAccount(accountNumber).close();
	}
	void suspendAccount(int accountNumber){
		FindBankAccount(accountNumber).suspend();
	}
	String getAccountState(int accountNumber){
		return FindBankAccount(accountNumber).getStatus();
	}
    String summarizeAccountTransactions(int accountNumber){
    	return FindBankAccount(accountNumber).getTransactions();
    }
    String summarizeAllAccounts(){
    	String tempString = "Bank Account Summary \n\nAccount        Balance      #Transactions       Status \n";
          for(BankAccount tempAccount:Account){
        	  tempString += (String.valueOf(tempAccount.accountNumber));
        	  tempString += (tempAccount.getBalance());
        	  tempString +=	 (String.valueOf(tempAccount.getTransactions()));	  
        	  tempString +=  tempAccount.getStatus()+"\n";
          }
          return tempString + "End of Account Summary ";
    }

	





}
